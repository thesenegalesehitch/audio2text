import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:share_plus/share_plus.dart';
import 'package:path_provider/path_provider.dart';

class TTSScreen extends StatefulWidget {
  const TTSScreen({super.key});

  @override
  State<TTSScreen> createState() => _TTSScreenState();
}

class _TTSScreenState extends State<TTSScreen> {
  final FlutterTts _flutterTts = FlutterTts();
  String _textToSpeak = '';
  bool _isSpeaking = false;
  List<dynamic> _voices = [];
  String? _selectedVoice;

  @override
  void initState() {
    super.initState();
    _initTTS();
  }

  Future<void> _initTTS() async {
    final voices = await _flutterTts.getVoices;
    setState(() {
      _voices = voices;
      if (_voices.isNotEmpty) {
        _selectedVoice = _voices.first['name'];
      }
    });
  }

  Future<void> _speak() async {
    if (_textToSpeak.trim().isEmpty) return;
    await _flutterTts.setVoice(_voices.firstWhere(
      (v) => v['name'] == _selectedVoice,
      orElse: () => _voices.first,
    ));
    await _flutterTts.speak(_textToSpeak);
    setState(() => _isSpeaking = true);
    _flutterTts.setCompletionHandler(() {
      setState(() => _isSpeaking = false);
    });
  }

  Future<void> _stop() async {
    await _flutterTts.stop();
    setState(() => _isSpeaking = false);
  }

  Future<void> _saveText() async {
    final dir = await getApplicationDocumentsDirectory();
    final fileName = 'tts_${DateTime.now().toIso8601String().replaceAll(':', '-')}.txt';
    final file = File('${dir.path}/$fileName');
    await file.writeAsString(_textToSpeak);
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Texte sauvegardé dans : ${file.path}')),
    );
  }

  void _shareText() {
    if (_textToSpeak.trim().isNotEmpty) {
      Share.share(_textToSpeak);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Texte vers Audio'),
      ),
      drawer: Drawer(
        child: ListView(
          children: [
            const DrawerHeader(
              decoration: BoxDecoration(
                gradient: LinearGradient(colors: [Colors.deepPurple, Colors.purple]),
              ),
              child: Text('Menu', style: TextStyle(color: Colors.white, fontSize: 24)),
            ),
            ListTile(
              leading: const Icon(Icons.mic),
              title: const Text('Audio vers Texte'),
              onTap: () => Navigator.pushReplacementNamed(context, '/stt'),
            ),
            ListTile(
              leading: const Icon(Icons.volume_up),
              title: const Text('Texte vers Audio'),
              onTap: () => Navigator.pop(context),
            ),
            ListTile(
              leading: const Icon(Icons.folder),
              title: const Text('Fichiers'),
              onTap: () => Navigator.pushReplacementNamed(context, '/files'),
            ),
          ],
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            TextField(
              maxLines: 4,
              decoration: const InputDecoration(
                hintText: 'Entrez votre texte...',
                border: OutlineInputBorder(),
              ),
              onChanged: (val) {
                setState(() {
                  _textToSpeak = val;
                });
              },
            ),
            const SizedBox(height: 10),
            DropdownButtonFormField<String>(
              value: _selectedVoice,
              decoration: const InputDecoration(labelText: 'Choisir une voix'),
              items: _voices.map<DropdownMenuItem<String>>((voice) {
                return DropdownMenuItem(
                  value: voice['name'],
                  child: Text('${voice['name']} (${voice['locale']})'),
                );
              }).toList(),
              onChanged: (val) {
                setState(() {
                  _selectedVoice = val;
                });
              },
            ),
            const SizedBox(height: 10),
            Row(
              children: [
                Expanded(
                  child: ElevatedButton.icon(
                    icon: Icon(_isSpeaking ? Icons.stop : Icons.volume_up),
                    label: Text(_isSpeaking ? 'Arrêter' : 'Parler'),
                    onPressed: _isSpeaking ? _stop : _speak,
                    style: ElevatedButton.styleFrom(
                      minimumSize: const Size.fromHeight(50),
                      backgroundColor: _isSpeaking ? Colors.red : Colors.green,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 10),
            Row(
              children: [
                Expanded(
                  child: ElevatedButton.icon(
                    icon: const Icon(Icons.save),
                    label: const Text('Sauvegarder'),
                    onPressed: _textToSpeak.trim().isEmpty ? null : _saveText,
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: ElevatedButton.icon(
                    icon: const Icon(Icons.share),
                    label: const Text('Partager'),
                    onPressed: _textToSpeak.trim().isEmpty ? null : _shareText,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
