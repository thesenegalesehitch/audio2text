import 'package:speech_to_text/speech_to_text.dart' as stt;

class STTService {
  final stt.SpeechToText _speech = stt.SpeechToText();
  bool _isInitialized = false;

  /// Initialise le service STT une seule fois
  Future<bool> _ensureInitialized() async {
    if (!_isInitialized) {
      _isInitialized = await _speech.initialize();
    }
    return _isInitialized;
  }

  /// Démarre l'écoute et retourne le texte transcrit.
  /// La durée peut être ajustée si nécessaire.
  Future<String> listen({
    String? localeId,
    Duration duration = const Duration(seconds: 5),
  }) async {
    String resultText = '';
    final available = await _ensureInitialized();

    if (!available) {
      throw Exception('SpeechToText non disponible');
    }

    await _speech.listen(
      localeId: localeId,
      listenMode: stt.ListenMode.dictation,
      onResult: (result) {
        resultText = result.recognizedWords;
      },
    );

    await Future.delayed(duration);
    await stop();

    return resultText;
  }

  /// Arrête l'écoute en cours
  Future<void> stop() async {
    if (_speech.isListening) {
      await _speech.stop();
    }
  }

  /// Retourne la liste des langues disponibles
  Future<List<stt.LocaleName>> getLocales() async {
    final available = await _ensureInitialized();
    if (!available) {
      throw Exception('SpeechToText non disponible');
    }
    return _speech.locales();
  }

  /// Retourne la locale système
  Future<stt.LocaleName?> getSystemLocale() async {
    final available = await _ensureInitialized();
    if (!available) {
      throw Exception('SpeechToText non disponible');
    }
    return _speech.systemLocale();
  }
}
